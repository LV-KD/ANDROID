package hkust.comp4521.courseinfo;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.content.res.XmlResourceParser;
import android.util.Log;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import java.io.IOException;
import java.net.URL;

import android.text.util.Linkify;

public class contacts extends Activity {
	
	// Add a new string
    public static final String DEBUG_TAG = "Contacts Log";
  
    ContactsTask contactprocessing;
    
    ProgressDialog waitDialog;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contacts);
        
        contactprocessing = new ContactsTask();
        
        contactprocessing.execute();

    }
    
    private class ContactsTask extends AsyncTask<Object, String, Boolean> {
        
        TableLayout contactsTable;
        XmlPullParser contactinfo;

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			
			waitDialog = ProgressDialog.show(contacts.this, "Contacts", "Loading ...");
		}
        
		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			waitDialog.dismiss();
		}


		@Override
		protected void onProgressUpdate(String... values) {
			// TODO Auto-generated method stub
			super.onProgressUpdate(values);
			
			if (values.length == 1){
				String strvalue = values[0];
				
				insertContactRow(contactsTable, strvalue);				
				
			}
			else{
				final TableRow newRow = new TableRow(contacts.this);
				TextView noResults = new TextView(contacts.this);
				newRow.addView(noResults);
				contactsTable.addView(newRow);				
			}
		}



		@Override
		protected Boolean doInBackground(Object... params) {

	        //Get pointers to the table layout in the contacts.xml file
	        contactsTable = (TableLayout) findViewById(R.id.contactsTable);
	        
	        // Open a XML resource parser to parse the contactinfo.xml file
	        // XmlResourceParser contactinfo = getResources().getXml(R.xml.contactinfo);
	        
	        try{
	        	URL xmlUrl = new URL("http://course.cse.ust.hk/comp4521/xml/contactinfo.xml");
	        	contactinfo = XmlPullParserFactory.newInstance().newPullParser();
	            contactinfo.setInput(xmlUrl.openStream(), null);
	        }catch (XmlPullParserException e){
	        	contactinfo = null;
	        }catch (IOException e){
	           contactinfo = null;
	        }
	        
	        // Now construct the information for the instructor and TA from the parsed XML file
	        try {
	        	// process the contacts xml file to set up the information on the activity screen
	            processcontacts(contactsTable, contactinfo);
	        } catch (Exception e) {
	            Log.e(DEBUG_TAG, "Failed to load Contacts", e);
	        }			
			return null;
		}
    	


		/**
		 * Churn through an XML score information and populate a {@code TableLayout}
		 * 
		 * @param contactsTable
		 *            The {@code TableLayout} to populate
		 *
		 * @param contact
		 *            A standard {@code XmlResourceParser} containing the scores
		 * @throws XmlPullParserException
		 *             Thrown on XML errors
		 * @throws IOException
		 *             Thrown on IO errors reading the XML
		 */
		private void processcontacts(final TableLayout contactsTable,
				XmlPullParser contact) throws XmlPullParserException,
				IOException {
			int eventType = -1;
			boolean bFoundContacts = false;
			// Find records from XML
			while (eventType != XmlResourceParser.END_DOCUMENT) {
				if (eventType == XmlResourceParser.START_TAG) {
					// Get the name of the tag (eg contact, instructor or assistant)
					String strName = contact.getName();
					if (strName.equals("instructor")) {
						bFoundContacts = true;
						publishProgress("Instructor");
						String name = contact.getAttributeValue(null, "name");
						publishProgress("     " + name);
						String office = contact.getAttributeValue(null, "office");
						publishProgress("     Office: " + office);
						String tel = contact.getAttributeValue(null, "tel");
						publishProgress("     Tel: " + tel);
						String email = contact.getAttributeValue(null, "email");
						publishProgress("     Email: " + email);
						String web = contact.getAttributeValue(null, "web");
						publishProgress("     Web: " + web);
						publishProgress("     ");

					}
					if (strName.equals("assistant")) {
						bFoundContacts = true;
						publishProgress("Teaching Assistant");
						String name = contact.getAttributeValue(null, "name");
						publishProgress("     " + name);
						String office = contact.getAttributeValue(null, "office");
						publishProgress("     Office: " + office);
						String tel = contact.getAttributeValue(null, "tel");
						publishProgress("     Tel: " + tel);
						String email = contact.getAttributeValue(null, "email");
						publishProgress("     Email: " + email);
						publishProgress("     ");
					}
				}
				eventType = contact.next();
			}
			// Handle no records available
			if (bFoundContacts == false) {
				publishProgress();
			}
		}

		/**
		 * {@code insertContactRow()} helper method -- Inserts a new contact information row {@code
		 * TableRow} in the {@code TableLayout}
		 * 
		 * @param contactTable
		 *            The {@code TableLayout} to add the contact information to
		 * @param strValue
		 *            The value of text string to be inserted into the row
		 * @param mask
		 *            specifies what regex I need to look for in the string in order to Linkify it. mask <= 0 implies no need to Linkify.
		 */
		private void insertContactRow(final TableLayout contactTable, String strValue) {
			// create a new table row and populate it
			final TableRow newRow = new TableRow(contacts.this);
			TextView textView = new TextView(contacts.this);
			textView.setText(strValue);
			Linkify.addLinks(textView, Linkify.ALL);
			if (strValue == "Instructor" || strValue == "Teaching Assistant"){
				textView.setTextSize(18);
				textView.setTextColor(getResources().getColor(R.color.ustgold));
			}
			newRow.addView(textView);
			contactTable.addView(newRow);
		}
    
    }

}
