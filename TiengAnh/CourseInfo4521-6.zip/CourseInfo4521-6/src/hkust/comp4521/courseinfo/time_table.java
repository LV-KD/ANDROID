package hkust.comp4521.courseinfo;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.content.res.XmlResourceParser;
import android.util.Log;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.io.IOException;
import java.net.URL;

public class time_table extends Activity {
	
    public static final String DEBUG_TAG = "Time Table Log";
    
    TimeTableTask timetableprocessing;
    
    ProgressDialog waitDialog;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timetable);
        
        timetableprocessing = new TimeTableTask();
        
        timetableprocessing.execute();
    }

    private class TimeTableTask extends AsyncTask<Object, String, Boolean> {
    	TableLayout timeTable;
        XmlPullParser timetableinfo;
    	
    	@Override
		protected Boolean doInBackground(Object... params) {
            
            //Get pointers to the two table layouts in the contacts.xml file
            timeTable = (TableLayout) findViewById(R.id.timeTable);
            
            try{
            	URL xmlUrl = new URL("http://course.cse.ust.hk/comp4521/xml/time_table.xml");
            	timetableinfo = XmlPullParserFactory.newInstance().newPullParser();
                timetableinfo.setInput(xmlUrl.openStream(), null);
            }catch (XmlPullParserException e){
            	timetableinfo = null;
            }catch (IOException e){
               timetableinfo = null;
            }
                   
            
            try {
                processtimetable(timeTable, timetableinfo);
            } catch (Exception e) {
                Log.e(DEBUG_TAG, "Failed to load Time Table", e);
            }
            
            // TODO Auto-generated method stub
			return null;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			waitDialog.dismiss();
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			waitDialog = ProgressDialog.show(time_table.this, "Time Table", "Loading ...");
		}

		@Override
		protected void onProgressUpdate(String... values) {
			// TODO Auto-generated method stub
			super.onProgressUpdate(values);
			
			if (values.length == 1){
				String strvalue = values[0];
				
				insertTimeTableRow(timeTable, strvalue);				
				
			}
			else{
				final TableRow newRow = new TableRow(time_table.this);
				TextView noResults = new TextView(time_table.this);
				newRow.addView(noResults);
				timeTable.addView(newRow);				
			}
		}

		/**
    	 * Churn through an XML score information and populate a {@code TableLayout}
    	 * 
    	 * @param lectureTable
    	 *            The {@code TableLayout} to populate
    	 * @param timetable
    	 *            A standard {@code XmlResourceParser} containing the scores
    	 * @throws XmlPullParserException
    	 *             Thrown on XML errors
    	 * @throws IOException
    	 *             Thrown on IO errors reading the XML
    	 */
    	private void processtimetable(final TableLayout timeTable,
    			XmlPullParser timetable) throws XmlPullParserException,
    			IOException {
    		int eventType = -1;
    		boolean bFoundTimeTable = false;
    		// Find records from XML
    		while (eventType != XmlResourceParser.END_DOCUMENT) {
    			if (eventType == XmlResourceParser.START_TAG) {
    				// Get the name of the tag (eg timetable, lecture or lab)
    				String strName = timetable.getName();
    				if (strName.equals("lecture")) {
    					bFoundTimeTable = true;
    					publishProgress("Lectures");
    					String days = timetable.getAttributeValue(null, "days");
    					publishProgress("     " + days);
    					String time = timetable.getAttributeValue(null, "time");
    					publishProgress("     Time: " + time);
    					String room = timetable.getAttributeValue(null, "room");
    					publishProgress("     Room: " + room);
    					publishProgress("     ");

    				}
    				if (strName.equals("lab")) {
    					bFoundTimeTable = true;
    					publishProgress("Lab Sessions");
    					String days = timetable.getAttributeValue(null, "days");
    					publishProgress("     " + days);
    					String time = timetable.getAttributeValue(null, "time");
    					publishProgress("     Time: " + time);
    					String room = timetable.getAttributeValue(null, "room");
    					publishProgress("     Room: " + room);
    					publishProgress("     ");
    				}
    			}
    			eventType = timetable.next();
    		}
    		// Handle no records available
    		if (bFoundTimeTable == false) {
    			final TableRow newRow = new TableRow(time_table.this);
    			TextView noResults = new TextView(time_table.this);
    			newRow.addView(noResults);
    			timeTable.addView(newRow);
    		}
    	}

    	/**
    	 * {@code insertTimeTableRow()} helper method -- Inserts a new time table row {@code
    	 * TableRow} in the {@code TableLayout}
    	 * 
    	 * @param timeTable
    	 *            The {@code TableLayout} to add the time table information to
    	 * @param strValue
    	 *            The value of the  text string to be inserted into the row
    	 */
    	private void insertTimeTableRow(final TableLayout timeTable, String strValue) {
    		final TableRow newRow = new TableRow(time_table.this);
    		TextView textView = new TextView(time_table.this);
    		textView.setText(strValue);
    		if (strValue == "Lectures" || strValue == "Lab Sessions"){
    			textView.setTextSize(18);
    			textView.setTextColor(getResources().getColor(R.color.ustgold));        	
    		}
    		newRow.addView(textView);
    		timeTable.addView(newRow);
    	}
    }
}
